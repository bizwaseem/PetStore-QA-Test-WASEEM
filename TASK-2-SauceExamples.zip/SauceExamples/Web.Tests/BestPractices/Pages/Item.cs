namespace Selenium3.Nunit.Framework.BestPractices.Pages
{
    public enum Item
    {
        Backpack
    }
}