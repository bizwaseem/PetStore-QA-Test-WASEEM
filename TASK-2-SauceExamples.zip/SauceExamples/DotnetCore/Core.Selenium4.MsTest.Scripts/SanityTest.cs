using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Core.Selenium4.MsTest.Scripts
{
    [TestClass]
    public class SanityTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.IsTrue(true);
        }
    }
}
