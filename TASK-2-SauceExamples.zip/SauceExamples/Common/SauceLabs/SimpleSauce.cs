﻿namespace Common.SauceLabs
{
    public class SimpleSauce
    {
        public Rdc Rdc => new Rdc();
        public EmusimAPI EmuSim => new EmusimAPI();
    }
}