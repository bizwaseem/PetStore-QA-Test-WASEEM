﻿namespace Common.SauceLabs
{
    public class ApiKeys
    {
        public RdcKeys Rdc => new RdcKeys();
    }

    public class RdcKeys
    {
        public App Apps => new App();
    }
}
